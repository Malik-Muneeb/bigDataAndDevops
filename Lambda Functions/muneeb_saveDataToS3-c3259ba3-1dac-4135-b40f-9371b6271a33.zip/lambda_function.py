import json
import boto3
from pprint import pprint

def lambda_handler(event, context):
    """
    It will invoke muneeb_getDataFromCity and muneeb_getDataFromCountry functions and save data to S3 Bucket
    """
    
    # Invoking Lambda Function 1 
    invokeLam = boto3.client("lambda", region_name = "us-east-1")
    dataFromCity = invokeLam.invoke(FunctionName = "muneeb_getDataFromCity", InvocationType = "RequestResponse")
    
    # Invoking Lambda Function 2
    dataFromCountry = invokeLam.invoke(FunctionName = "muneeb_getDataFromCountry", InvocationType = "RequestResponse")
    
    cities = dataFromCity["Payload"].read()
    countries = dataFromCountry["Payload"].read()
    print("Response from 1st Function: ", cities)
    print("Response from 2nd Function: ", countries)
    
    # Clinet for Saving Data to S3
    s3 = boto3.client("s3")
    status = "Successful Execution"
    
    s3.put_object(Bucket = "thebucketofmuneeb", Key = "cities.txt", Body = cities)
    s3.put_object(Bucket = "thebucketofmuneeb", Key = "countries.txt", Body = countries)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Data saved successfully!')
    }
